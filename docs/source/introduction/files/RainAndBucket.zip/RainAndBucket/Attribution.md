﻿This project includes art assets produced by other people.

### Water Drop Sound

Title: waterdrop24.wav
Creator: jazzy.junggle.net
Source: [waterdrop24.wav](https://freesound.org/people/junggle/sounds/30341/)
License: [Creative Commons Attribution 4.0 License](https://creativecommons.org/licenses/by/4.0/)

### Rain Sounds

Title: UnderTreeInRain.mp3
Creator: acclivity
Source: [UnderTreeInRain.mp3](https://freesound.org/people/acclivity/sounds/28283/)
License: [Creative Commons Noncommercial 4.0 License](https://creativecommons.org/licenses/by-nc/4.0/)


### Droplet Sprite

Title: drop.png
Creator: Quillraven
Source: [drop.png](https://raw.githubusercontent.com/Quillraven/SimpleKtxGame/01-app/android/assets/images/drop.png)
License: Unknown, no license listed


### Bucket Sprite

Title: bucket.png
Creator: Quillraven
Source: [bucket.png](https://raw.githubusercontent.com/Quillraven/SimpleKtxGame/01-app/android/assets/images/bucket.png)
License: Unknown, no license listed
