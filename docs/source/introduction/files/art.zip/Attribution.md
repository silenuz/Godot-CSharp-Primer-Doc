All images used in this project are from the Platformer Pack Redux by Kenney

### All Images

* Title: Platformer Pack Redux
* Creator: www.kenney.nl
* Source: [platformer-pack-redux-360-assets.zip](https://www.kenney.nl/content/3-assets/123-platformer-pack-redux/platformer-pack-redux-360-assets.zip)
* License: [CC0 1.0 Universal](https://creativecommons.org/publicdomain/zero/1.0/)